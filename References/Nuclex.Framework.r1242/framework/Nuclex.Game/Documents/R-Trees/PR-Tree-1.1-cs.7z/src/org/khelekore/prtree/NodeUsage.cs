using System;
using System.Collections.Generic;

namespace org.khelekore.prtree {

  /** Information needed to be able to figure out how an
   *  element of the tree is currently used.
   */
  internal class NodeUsage<T> {

    public NodeUsage(T data) {
      this.data = data;
    }

    public T Data {
      get { return data; }
    }

    public void Use() {
      if(usage >= 0)
        usage = -usage;
      else
        throw new InvalidOperationException("using already used node");
    }

    public bool IsUsed {
      get { return usage < 0; }
    }

    public int User {
      get { return Math.Abs(usage); }
      set {
        if(value < 0)
          throw new ArgumentException("id must be positive");

        usage = value;
      }
    }

    public override String ToString() {
      return
        "{data: " + data +
        ", used: " + IsUsed + ", user: " + User + "}";
    }

    /** The actual data of the node. */
    private T data;
    /** The leaf node builder user id (split id). */
    private int usage = 1;

  }

} // namespace org.khelekore.prtree