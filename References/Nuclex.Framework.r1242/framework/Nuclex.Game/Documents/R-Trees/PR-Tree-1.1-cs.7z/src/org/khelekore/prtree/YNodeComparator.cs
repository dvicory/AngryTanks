using System;
using System.Collections.Generic;

namespace org.khelekore.prtree {

  internal class YNodeComparator<T> : IComparer<INode<T>> {

    public YNodeComparator(IMBRConverter<T> converter) {
      this.converter = converter;
    }

    public int Compare(INode<T> n1, INode<T> n2) {
      double d1 = n1.GetMBR(converter).MinY;
      double d2 = n2.GetMBR(converter).MinY;
      return Comparer<double>.Default.Compare(d1, d2);
    }

    private IMBRConverter<T> converter;

  }

} // namespace org.khelekore.prtree
