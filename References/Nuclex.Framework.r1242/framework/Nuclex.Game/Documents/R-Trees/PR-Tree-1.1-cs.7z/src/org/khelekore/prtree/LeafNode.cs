using System;
using System.Collections.Generic;

namespace org.khelekore.prtree {

  internal class LeafNode<ItemType> : NodeBase<ItemType, ItemType> {

    public LeafNode(Object[] data) : base(data) { }

    public IMBR getMBR(ItemType t, IMBRConverter<ItemType> converter) {
      return new SimpleMBR(
        converter.getMinX(t), converter.getMinY(t),
        converter.getMaxX(t), converter.getMaxY(t)
      );
    }

    public override IMBR ComputeMBR(IMBRConverter<ItemType> converter) {
      IMBR ret = null;
      for(int i = 0, s = Size; i < s; i++) {
        ret = GetUnion(ret, getMBR(this[i], converter));
      }
      return ret;
    }

    public override void Expand(
      IMBR mbr, IMBRConverter<ItemType> converter, List<ItemType> found, List<INode<ItemType>> nodesToExpand
    ) {
      Find(mbr, converter, found);
    }

    public override void Find(IMBR mbr, IMBRConverter<ItemType> converter, List<ItemType> result) {
      for(int i = 0, s = Size; i < s; i++) {
        ItemType t = this[i];
        if(mbr.Intersects(t, converter))
          result.Add(t);
      }
    }

  }

} // namespace org.khelekore.prtree