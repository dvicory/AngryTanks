using System;
using System.Collections.Generic;

namespace org.khelekore.prtree {

  internal class XNodeComparator<T> : IComparer<INode<T>> {

    public XNodeComparator(IMBRConverter<T> converter) {
      this.converter = converter;
    }

    public int Compare(INode<T> n1, INode<T> n2) {
      double d1 = n1.GetMBR(converter).MinX;
      double d2 = n2.GetMBR(converter).MinX;
      return Comparer<double>.Default.Compare(d1, d2);
    }

    private IMBRConverter<T> converter;

  }

} // namespace org.khelekore.prtree
