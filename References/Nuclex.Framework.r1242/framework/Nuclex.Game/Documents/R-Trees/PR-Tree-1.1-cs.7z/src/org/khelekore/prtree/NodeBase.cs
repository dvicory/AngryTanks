using System;
using System.Collections.Generic;

namespace org.khelekore.prtree {

  /// <summary>Common base class for shared node functionality</summary>
  /// <typeparam name="ChildType">Type of the child entries</typeparam>
  /// <typeparam name="ItemType">Type of the data entries</typeparam>
  public abstract class NodeBase<ChildType, ItemType> : INode<ItemType> {

    /// <summary>Initializes a new node base instance</summary>
    /// <param name="data">Items being stored in the node</param>
    public NodeBase(Object[] data) {
      this.data = data;
    }

    /// <summary>
    ///   The size of the node, that is how many data elements it holds
    /// </summary>
    public int Size {
      get { return data.Length; }
    }

    /// <summary>Retrieves an item stored in the node</summary>
    /// <param name="index">Index of the item that will be retrieves</param>
    /// <returns>The item at the specified index</returns>
    public ChildType this[int index] {
      get { return (ChildType)data[index]; } // WTF? Downcast?
    }

    /// <summary>Returns the MBR of this node</summary>
    /// <param name="converter">MBR converter to use for obtaining an item's MBR</param>
    /// <returns>The MBR of the node</returns>
    public IMBR GetMBR(IMBRConverter<ItemType> converter) {
      if(mbr == null)
        mbr = ComputeMBR(converter);
      return mbr;
    }

    /// <summary>Computes the MBR of the node</summary>
    /// <param name="converter">
    ///   MBR converter that will be use to obtain an item's MBR
    /// </param>
    /// <returns>The MBR of the node</returns>
    public abstract IMBR ComputeMBR(IMBRConverter<ItemType> converter);

    /// <summary>Obtains the union MBR of the two MBRs</summary>
    /// <param name="m1">First MBR to build a union of</param>
    /// <param name="m2">First MBR to build a union of</param>
    /// <returns>The union of the two MBRs</returns>
    public IMBR GetUnion(IMBR m1, IMBR m2) {
      if(m1 == null)
        return m2;

      return m1.Union(m2);
    }

    /// <summary>
    ///   Visits this node and add the leafs to the found list and adds any
    ///   child nodes to the list of nodes to expand.
    /// </summary>
    /// <param name="mbr">MBR of the nodes that will be visited</param>
    /// <param name="converter">MBR converter to use for obtaining an item's MBR</param>
    /// <param name="found">Items that were found in the queried MBR</param>
    /// <param name="nodesToExpand">Other nodes that need to be expanded</param>
    public abstract void Expand(
      IMBR mbr, IMBRConverter<ItemType> converter,
      List<ItemType> found, List<INode<ItemType>> nodesToExpand
    );

    /// <summary>Finds all nodes that intersect with the given MBR.</summary>
    /// <param name="mbr">MBR that will be checked for intersection</param>
    /// <param name="converter">MBR converter to use for obtaining an item's MBR</param>
    /// <param name="result">Received that items that were found in the MBR</param>
    public abstract void Find(IMBR mbr, IMBRConverter<ItemType> converter, List<ItemType> result);

    private IMBR mbr;
    private Object[] data;

  }

} // namespace org.khelekore.prtree