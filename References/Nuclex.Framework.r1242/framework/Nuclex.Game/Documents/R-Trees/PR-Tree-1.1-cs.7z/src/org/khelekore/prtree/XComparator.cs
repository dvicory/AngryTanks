using System;
using System.Collections.Generic;

namespace org.khelekore.prtree {

  internal class XComparator<T> : IComparer<T> {

    public XComparator(IMBRConverter<T> converter) {
      this.converter = converter;
    }

    public int Compare(T t1, T t2) {
      double d1 = converter.getMinX(t1);
      double d2 = converter.getMinX(t2);
      return Comparer<double>.Default.Compare(d1, d2);
    }

    private IMBRConverter<T> converter;

  }

} // namespace org.khelekore.prtree
