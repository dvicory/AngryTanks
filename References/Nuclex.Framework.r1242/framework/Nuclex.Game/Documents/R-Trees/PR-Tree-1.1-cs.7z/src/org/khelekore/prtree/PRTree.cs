using System;
using System.Collections;
using System.Collections.Generic;

namespace org.khelekore.prtree {

  /// <summary>A Priority R-Tree, a spatial index.</summary>
  /// <remarks>
  ///   <para>
  ///     This tree only supports bulk loading.
  ///   </para>
  ///   <example>
  ///     <code>
  ///       PRTree&lt;Rectangle2D&gt; tree = new PRTree&lt;Rectangle2D&gt;(
  ///         new Rectangle2DConverter(), 10
  ///       );
  ///        
  ///       Rectangle2D rx = new Rectangle2D.Double(0, 0, 1, 1);
  ///       tree.Load(Collections.singletonList(rx));
  ///        
  ///       for (Rectangle2D r : tree.find (0, 0, 1, 1)) {
  ///         System.Console.WriteLine("found a rectangle: " + r);
  ///       }
  ///     </code>
  ///   </example>
  /// </remarks>
  /// <typeparam name="ItemType">The data type stored in the tree</typeparam>
  public class PRTree<ItemType> {

    #region class Finder

    private class Finder : IEnumerator<ItemType> {

      public Finder(IMBR mbr, PRTree<ItemType> tree) { // Node<T> root) {
        this.tree = tree;
        //this.root = root;
        this.mbr = mbr;
        toVisit.Add(this.tree.root);
        findNext();
      }

      //Node<T> root;
      private PRTree<ItemType> tree;

      public bool hasNext() {
        return !endReached; // next != null;
      }

      public ItemType Next() {
        ItemType toReturn = next;
        findNext();
        return toReturn;
      }

      public ItemType Current { get { return this.next; } }
      public bool MoveNext() { if(next == null) { return false; } else { findNext(); return true; } }
      public void Reset() { endReached = false; toVisit.Clear(); toVisit.Add(this.tree.root); findNext(); }
      public void Dispose() { }
      object IEnumerator.Current { get { return Current; } }


      private void findNext() {
        while((ts.Count == 0) && (toVisit.Count > 0)) {
          INode<ItemType> n = toVisit[toVisit.Count - 1];
          toVisit.RemoveAt(toVisit.Count - 1);
          visitedNodes++;
          n.Expand(mbr, this.tree.converter, ts, toVisit);
        }
        if(ts.Count == 0) {
          next = default(ItemType); // was null
          endReached = true;
        } else {
          next = ts[ts.Count - 1];
          ts.RemoveAt(ts.Count - 1);
          dataNodesVisited++;
        }
      }

      public void remove() {
        throw new NotSupportedException("Not implemented");
      }

      private IMBR mbr;

      private List<ItemType> ts = new List<ItemType>();
      private List<INode<ItemType>> toVisit = new List<INode<ItemType>>();
      private ItemType next;

      private int visitedNodes = 0;
      private int dataNodesVisited = 0;
      
      private bool endReached;

    }

    #endregion // class Finder

    #region class LeafNodeFactory

    private class LeafNodeFactory : LeafBuilder.NodeFactory<LeafNode<ItemType>> {
      public LeafNode<ItemType> create(Object[] data) {
        return new LeafNode<ItemType>(data);
      }
    }

    #endregion // class LeafNodeFactory

    #region class InternalNodeFactory

    private class InternalNodeFactory : LeafBuilder.NodeFactory<InternalNode<ItemType>> {
      public InternalNode<ItemType> create(Object[] data) {
        return new InternalNode<ItemType>(data);
      }
    }

    #endregion // class InternalNodeFactory

    /// <summary>
    ///   Creates a new PRTree using the specified branch factor.
    /// </summary>
    /// <param name="converter">
    ///   MBR converter that will be used for obtaining the MBR of an item
    /// </param>
    /// <param name="branchFactor">Number of child nodes for each internal node.</param>
    public PRTree(IMBRConverter<ItemType> converter, int branchFactor) {
      this.converter = converter;
      this.branchFactor = branchFactor;
    }

    /// <summary>Bulk-loads data into this tree.</summary>
    /// <typeparam name="ItemDerivedType">Type of the items that will be added</typeparam>
    /// <param name="data">collection of data to store in the tree.</param>
    /// <remarks>
    ///   Create the leaf nodes that each hold (up to) branchFactor data entries.
    ///   Then use the leaf nodes as data until we can fit all nodes into the root node.
    /// </remarks>
    /// <exception cref="InvalidOperationException">
    ///   Thrown if the tree is already loaded
    /// </exception>
    public void Load<ItemDerivedType>(ICollection<ItemDerivedType> data)
      where ItemDerivedType : ItemType {

      if(root != null)
        throw new InvalidOperationException("Tree is already loaded");

      numLeafs = data.Count;

      XComparator<ItemType> xSorter = new XComparator<ItemType>(converter);
      YComparator<ItemType> ySorter = new YComparator<ItemType>(converter);

      List<LeafNode<ItemType>> leafNodes = new List<LeafNode<ItemType>>(
        estimateSize(numLeafs)
      );

      LeafBuilder lb = new LeafBuilder(branchFactor);
      lb.BuildLeafs<ItemType, LeafNode<ItemType>, ItemDerivedType>(
        data, leafNodes, xSorter, ySorter, new LeafNodeFactory()
      );

      height = 1;

      if(leafNodes.Count < branchFactor) {
        setRoot<LeafNode<ItemType>>(leafNodes);
      } else {
        XNodeComparator<ItemType> xs = new XNodeComparator<ItemType>(converter);
        YNodeComparator<ItemType> ys = new YNodeComparator<ItemType>(converter);
        List<INode<ItemType>> nodes = new List<INode<ItemType>>(
          Helper.Upcast<INode<ItemType>, LeafNode<ItemType>>(leafNodes)
        );
        do {
          height++;
          int es = estimateSize(nodes.Count);
          List<InternalNode<ItemType>> internalNodes = new List<InternalNode<ItemType>>(es);
          lb.BuildLeafs(nodes, internalNodes, xs, ys, new InternalNodeFactory());
          nodes = new List<INode<ItemType>>(
            Helper.Upcast<INode<ItemType>, InternalNode<ItemType>>(internalNodes)
          );
        } while(nodes.Count > branchFactor);
        setRoot<INode<ItemType>>(nodes);
      }
    }

    /// <summary>Minimum bounding rectangle of the data stored in this tree</summary>
    public IMBR MBR {
      get { return root.GetMBR(converter); }
    }

    /// <summary>Number of data leafs in this tree</summary>
    public int NumberOfLeaves {
      get { return numLeafs; }
    }

    /// <summary>Height of this tree</summary>
    public int Height {
      get { return height; }
    }

    /// <summary>
    ///   Finds all objects that intersect the given rectangle and stores the found node
    ///   in the given list.
    /// </summary>
    /// <param name="xmin">Minimum x coordinate of the query rectangle</param>
    /// <param name="ymin">Minimum y coordinate of the query rectangle</param>
    /// <param name="xmax">Maximum x coordinate of the query rectangle</param>
    /// <param name="ymax">Maximum y coordinate of the query rectangle</param>
    /// <param name="resultNodes">List that will be filled with the result</param>
    /// <exception cref="ArgumentException">
    ///   If xmin &gt; xmax or ymin &gt; ymax
    /// </exception>
    public void Find(
      double xmin, double ymin, double xmax, double ymax, List<ItemType> resultNodes
    ) {
      IMBR mbr = new SimpleMBR(xmin, ymin, xmax, ymax);
      Find(mbr, resultNodes);
    }

    /// <summary>
    ///   Finds all objects that intersect the given rectangle and stores the found nodes
    ///   in the given list.
    /// </summary>
    /// <param name="query">Region that will be queried for items</param>
    /// <param name="resultNodes">List that will be filled with the result</param>
    /// <exception cref="ArgumentException">
    ///   If xmin &gt; xmax or ymin &gt; ymax
    /// </exception>
    public void Find(IMBR query, List<ItemType> resultNodes) {
      validateRect(
        query.MinX, query.MinY, query.MaxX, query.MaxY
      );
      root.Find(query, converter, resultNodes);
    }

    /// <summary>Finds all items that intersect the given rectangle</summary>
    /// <param name="query">Query region in which items will be found</param>
    /// <returns>An enumerable set of the items in the query region</returns>
    /// <exception cref="ArgumentException">
    ///   If xmin &gt; xmax or ymin &gt; ymax
    /// </exception>
    public IEnumerable<ItemType> Find(IMBR query) {
      validateRect(
        query.MinX, query.MinY, query.MaxX, query.MaxY
      );

      Finder finder = new Finder(query, this);
      while(finder.hasNext()) {
        yield return finder.Next();
      }
    }

    /// <summary>
    ///   Finds all objects that intersect the given rectangle.
    /// </summary>
    /// <param name="xmin">Minimum x coordinate of the query rectangle</param>
    /// <param name="ymin">Minimum y coordinate of the query rectangle</param>
    /// <param name="xmax">Maximum x coordinate of the query rectangle</param>
    /// <param name="ymax">Maximum y coordinate of the query rectangle</param>
    /// <returns>An enumerable set of the items in the query region</returns>
    /// <exception cref="ArgumentException">
    ///   If xmin &gt; xmax or ymin &gt; ymax
    /// </exception>
    public IEnumerable<ItemType> Find(
      double xmin, double ymin, double xmax, double ymax
    ) {
      IMBR mbr = new SimpleMBR(xmin, ymin, xmax, ymax);
      return Find(mbr);
    }

    private void setRoot<N>(List<N> nodes) where N : INode<ItemType> {
      if(nodes.Count == 0)
        root = new InternalNode<ItemType>(new Object[0]);
      else if(nodes.Count == 1) {
        root = nodes[0];
      } else {
        height++;

        root = new InternalNode<ItemType>(
          new List<object>(Helper.Upcast<object, N>(nodes)).ToArray()
        );
      }
    }

    private void validateRect(
      double xmin, double ymin, double xmax, double ymax
    ) {
      if(xmax < xmin)
        throw new ArgumentException("xmax: " + xmax + " < xmin: " + xmin);
      if(ymax < ymin)
        throw new ArgumentException("ymax: " + ymax + " < ymin: " + ymin);
    }

    private int estimateSize(int dataSize) {
      return (int)(1.0 / (branchFactor - 1) * dataSize);
    }

    private IMBRConverter<ItemType> converter;
    private int branchFactor;

    private INode<ItemType> root;
    private int numLeafs;
    private int height;

  }

} // namespace org.khelekore.prtree
