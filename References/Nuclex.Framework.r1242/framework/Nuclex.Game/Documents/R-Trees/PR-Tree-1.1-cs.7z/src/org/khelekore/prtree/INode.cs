using System;
using System.Collections.Generic;

namespace org.khelekore.prtree {

  /// <summary>A node in a Priority R-Tree</summary>
  /// <typeparam name="ItemType">Type of the items stored in the tree</typeparam>
  public interface INode<ItemType> {

    /// <summary>
    ///   The size of the node, that is how many data elements it holds
    /// </summary>
    int Size { get; }

    /// <summary>Returns the MBR of this node</summary>
    /// <param name="converter">MBR converter to use for obtaining an item's MBR</param>
    /// <returns>The MBR of the node</returns>
    IMBR GetMBR(IMBRConverter<ItemType> converter);

    /// <summary>
    ///   Visits this node and add the leafs to the found list and adds any
    ///   child nodes to the list of nodes to expand.
    /// </summary>
    /// <param name="mbr">MBR of the nodes that will be visited</param>
    /// <param name="converter">MBR converter to use for obtaining an item's MBR</param>
    /// <param name="found">Items that were found in the queried MBR</param>
    /// <param name="nodesToExpand">Other nodes that need to be expanded</param>
    void Expand(
      IMBR mbr, IMBRConverter<ItemType> converter,
      List<ItemType> found, List<INode<ItemType>> nodesToExpand
    );

    /// <summary>Finds all nodes that intersect with the given MBR.</summary>
    /// <param name="mbr">MBR that will be checked for intersection</param>
    /// <param name="converter">MBR converter to use for obtaining an item's MBR</param>
    /// <param name="result">Received that items that were found in the MBR</param>
    void Find(IMBR mbr, IMBRConverter<ItemType> converter, List<ItemType> result);

  }

} // namespace org.khelekore.prtree {
