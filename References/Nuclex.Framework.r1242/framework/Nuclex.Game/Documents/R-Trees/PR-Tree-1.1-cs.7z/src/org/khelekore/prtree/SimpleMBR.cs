using System;
using System.Collections.Generic;

namespace org.khelekore.prtree {

  /// <summary>
  ///   An implementation of MBR that keeps 4 double values for the actual min and
  ///   max values needed.
  /// </summary>
  public class SimpleMBR : IMBR {

    /// <summary>Initializes a new MBR</summary>
    /// <param name="xmin">Minimum x coordinate</param>
    /// <param name="ymin">Minimum y coordinate</param>
    /// <param name="xmax">Maximum x coordinate</param>
    /// <param name="ymax">Maximum y coordinate</param>
    public SimpleMBR(double xmin, double ymin, double xmax, double ymax) {
      this.xmin = xmin;
      this.ymin = ymin;
      this.xmax = xmax;
      this.ymax = ymax;
    }

    /// <summary>Gets a string representation of this MBR</summary>
    /// <returns>A string describing the MBR</returns>
    public override string ToString() {
      return
        "{xmin: " + xmin + ", ymin: " + ymin +
        ", xmax: " + xmax + ", ymax: " + ymax + "}";
    }

    /// <summary>The minimum x value</summary>
    public double MinX {
      get { return xmin; }
    }

    /// <summary>The minimum y value</summary>
    public double MinY {
      get { return ymin; }
    }

    /// <summary>The maximum x value</summary>
    public double MaxX {
      get { return xmax; }
    }

    /// <summary>The maximum y value</summary>
    public double MaxY {
      get { return ymax; }
    }

    /// <summary>Creates a new MBR that is the union of this MBR and another</summary>
    /// <param name="other">Other MBR the union will be created with</param>
    /// <returns>The union of this MBR and the other MBR</returns>
    public IMBR Union(IMBR other) {
      double uxmin = Math.Min(xmin, other.MinX);
      double uymin = Math.Min(ymin, other.MinY);
      double uxmax = Math.Max(xmax, other.MaxX);
      double uymax = Math.Max(ymax, other.MaxY);
      return new SimpleMBR(uxmin, uymin, uxmax, uymax);
    }

    /// <summary>Checks if the other MBR intersects this one</summary>
    /// <param name="other">Other MBR that will be checked for intersection</param>
    /// <returns>True of the other MBR intersects this one</returns>
    public bool Intersects(IMBR other) {
      return !(
        other.MaxX < xmin ||
        other.MinX > xmax ||
        other.MaxY < ymin ||
        other.MinY > ymax
      );
    }

    /// <summary>
    ///   Check if this MBR intersects the rectangle given by the object
    ///   and the MBRConverter.
    /// </summary>
    /// <typeparam name="ItemType">Type of the item to check for intersection</typeparam>
    /// <param name="item">Item that will be checked for intersection</param>
    /// <param name="converter">
    ///   MBR converter that will be used to obtain the item's MBR
    /// </param>
    /// <returns>True of the item intersects with this MBR</returns>
    public bool Intersects<ItemType>(ItemType item, IMBRConverter<ItemType> converter) {
      return !(
        converter.getMaxX(item) < xmin ||
        converter.getMinX(item) > xmax ||
        converter.getMaxY(item) < ymin ||
        converter.getMinY(item) > ymax
      );
    }

    private double xmin;
    private double ymin;
    private double xmax;
    private double ymax;

  }

} // namespace org.khelekore.prtree
