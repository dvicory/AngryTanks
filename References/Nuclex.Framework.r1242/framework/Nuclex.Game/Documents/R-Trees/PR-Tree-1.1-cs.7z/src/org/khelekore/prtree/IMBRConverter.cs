using System;
using System.Reflection;

namespace org.khelekore.prtree {

  /// <summary>
  ///   Given an ItemType instance can tell the minimum and maximum coordinates
  ///   for that object
  /// </summary>
  /// <typeparam name="ItemType">Type of the items stored in the PRTree</typeparam>
  public interface IMBRConverter<ItemType> {

    /// <summary>Gets the minimum x coordinate value for the given object</summary>
    /// <param name="item">object to get the mbr coordinate for</param>
    /// <returns>The minimum x coordinate of the object</returns>
    double getMinX(ItemType item);

    /// <summary>Gets the minimum y coordinate value for the given object</summary>
    /// <param name="item">object to get the mbr coordinate for</param>
    /// <returns>The minimum y coordinate of the object</returns>
    double getMinY(ItemType item);

    /// <summary>Gets the maximum x coordinate value for the given object</summary>
    /// <param name="item">object to get the mbr coordinate for</param>
    /// <returns>The maximum x coordinate of the object</returns>
    double getMaxX(ItemType item);

    /// <summary>Gets the maximum y coordinate value for the given object</summary>
    /// <param name="item">object to get the mbr coordinate for</param>
    /// <returns>The maximum y coordinate of the object</returns>
    double getMaxY(ItemType item);

  }

} // namespace org.khelekore.prtree