using System;
using System.Collections.Generic;

namespace org.khelekore.prtree {

  /** Sort NodeUsage elements on their data elements.
   */
  internal class NodeUsageSorter<T> : IComparer<NodeUsage<T>> {

    public NodeUsageSorter(IComparer<T> sorter) {
      this.sorter = sorter;
    }

    public int Compare(NodeUsage<T> n1, NodeUsage<T> n2) {
      return sorter.Compare(n1.Data, n2.Data);
    }

    private IComparer<T> sorter;

  }

} // namespace org.khelekore.prtree