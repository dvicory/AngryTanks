﻿using System;
using System.Collections.Generic;

namespace org.khelekore.prtree {

  /// <summary>Helper routines for the R-Tree classes</summary>
  internal static class Helper {

    /// <summary>Upcasts all elements of an enumerable set</summary>
    /// <typeparam name="BaseType">Type that will be upcasted to</typeparam>
    /// <typeparam name="DerivedType">Type of the elements being upcasted</typeparam>
    /// <param name="enumerable">
    ///   Enumerable set of the elements that will be upcasted
    /// </param>
    /// <returns>A new enumerable set of the upcasted elements</returns>
    public static IEnumerable<BaseType> Upcast<BaseType, DerivedType>(
      IEnumerable<DerivedType> enumerable
    ) where DerivedType : BaseType {
      foreach(DerivedType derived in enumerable) {
        yield return derived;
      }
    }

  }

} // namespace org.khelekore.prtree
