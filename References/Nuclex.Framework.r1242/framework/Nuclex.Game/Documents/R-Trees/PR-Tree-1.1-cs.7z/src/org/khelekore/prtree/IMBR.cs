namespace org.khelekore.prtree {

  /// <summary>A minimum bounding rectangle</summary>
  public interface IMBR {

    /// <summary>The minimum x value</summary>
    double MinX { get; }

    /// <summary>The minimum y value</summary>
    double MinY { get; }

    /// <summary>The maximum x value</summary>
    double MaxX { get; }

    /// <summary>The maximum y value</summary>
    double MaxY { get; }

    /// <summary>Creates a new MBR that is the union of this MBR and another</summary>
    /// <param name="mbr">Other MBR the union will be created with</param>
    /// <returns>The union of this MBR and the other MBR</returns>
    IMBR Union(IMBR mbr);

    /// <summary>Checks if the other MBR intersects this one</summary>
    /// <param name="other">Other MBR that will be checked for intersection</param>
    /// <returns>True of the other MBR intersects this one</returns>
    bool Intersects(IMBR other);

    /// <summary>
    ///   Check if this MBR intersects the rectangle given by the object
    ///   and the MBRConverter.
    /// </summary>
    /// <typeparam name="ItemType">Type of the item to check for intersection</typeparam>
    /// <param name="item">Item that will be checked for intersection</param>
    /// <param name="converter">
    ///   MBR converter that will be used to obtain the item's MBR
    /// </param>
    /// <returns>True of the item intersects with this MBR</returns>
    bool Intersects<ItemType>(ItemType item, IMBRConverter<ItemType> converter);

  }

} // namespace org.khelekore.prtree