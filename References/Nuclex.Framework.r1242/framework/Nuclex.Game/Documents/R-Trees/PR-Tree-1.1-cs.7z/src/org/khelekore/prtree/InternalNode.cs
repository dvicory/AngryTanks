using System;
using System.Collections.Generic;

namespace org.khelekore.prtree {

  internal class InternalNode<ItemType> : NodeBase<INode<ItemType>, ItemType> {

    public InternalNode(Object[] data) : base(data) { }

    public override IMBR ComputeMBR(IMBRConverter<ItemType> converter) {
      IMBR ret = null;
      for(int i = 0, s = Size; i < s; i++)
        ret = GetUnion(ret, this[i].GetMBR(converter));
      return ret;
    }

    public override void Expand(
      IMBR mbr, IMBRConverter<ItemType> converter,
      List<ItemType> found, List<INode<ItemType>> nodesToExpand
    ) {
      for(int i = 0, s = Size; i < s; i++) {
        INode<ItemType> n = this[i];
        if(mbr.Intersects(n.GetMBR(converter)))
          nodesToExpand.Add(n);
      }
    }

    public override void Find(
      IMBR mbr, IMBRConverter<ItemType> converter, List<ItemType> result
    ) {
      for(int i = 0, s = Size; i < s; i++) {
        INode<ItemType> n = this[i];
        if(mbr.Intersects(n.GetMBR(converter)))
          n.Find(mbr, converter, result);
      }
    }

  }

} // namespace org.khelekore.prtree
