/*
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.khelekore.prtree.MBR;
import org.khelekore.prtree.MBRConverter;
import org.khelekore.prtree.PRTree;
import org.khelekore.prtree.SimpleMBR;

import static org.junit.Assert.*;

*/

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;

using NUnit.Framework;

using org.khelekore.prtree;

namespace org.khelekore.prtree.nunit {

  /// <summary>Unit tests for the PR-Tree</summary>
  [TestFixture]
  public class PRTreeTest {

    #region class RectangleFConverter

    private class RectangleFConverter : IMBRConverter<RectangleF> {

      public double getMinX(RectangleF t) {
        return t.Left;
      }

      public double getMinY(RectangleF t) {
        return t.Top;
      }

      public double getMaxX(RectangleF t) {
        return t.Right;
      }

      public double getMaxY(RectangleF t) {
        return t.Bottom;
      }

    }

    #endregion // RectangleFConverter

    #region class ShuffleSortComparer

    private class ShuffleSortComparer : IComparer<RectangleF> {

      public ShuffleSortComparer(Random random) {
        this.random = random;
      }

      public int Compare(RectangleF x, RectangleF y) {
        if(x != y) {
          return this.random.Next(-1, +2);
        } else {
          return 0;
        }
      }

      private Random random;

    }

    #endregion // class ShuffleSortComparer

    /// <summary>Called before each test is run</summary>
    [SetUp]
    public void SetUp() {
      tree = new PRTree<RectangleF>(converter, 10);
    }

    /// <summary>Verifies the behavior of an empty tree</summary>
    [Test]
    public void TestEmpty() {
      tree.Load(new List<RectangleF>());
      foreach(RectangleF r in tree.Find(0, 0, 1, 1)) {
        Assert.Fail("should not get any results");
      }

      Assert.IsNull(tree.MBR, "mbr of empty tress should be null");
      Assert.AreEqual(1, tree.Height, "height of empty tree");
    }

    /// <summary>Tests the behavior of the PR-Tree with a single rectangle</summary>
    [Test]
    public void TestSingle() {
      RectangleF rx = new RectangleF(0, 0, 1, 1);
      tree.Load(new RectangleF[] { rx });

      IMBR mbr = tree.MBR;
      Assert.AreEqual(0, mbr.MinX, "odd min for mbr");
      Assert.AreEqual(0, mbr.MinY, "odd min for mbr");
      Assert.AreEqual(1, mbr.MaxX, "odd min for mbr");
      Assert.AreEqual(1, mbr.MaxY, "odd min for mbr");
      Assert.AreEqual(1, tree.Height, "height of tree with one entry");

      int count = 0;
      foreach(RectangleF r in tree.Find(0, 0, 1, 1)) {
        Assert.AreEqual(r, rx, "odd rectangle returned");
        ++count;
      }
      Assert.AreEqual(1, count, "odd number of rectangles returned");

      foreach(RectangleF r in tree.Find(5, 5, 6, 7)) {
        Assert.Fail("should not find any rectangle");
      }

      foreach(RectangleF r in tree.Find(-5, -5, -2, -4)) {
        Assert.Fail("should not find any rectangle");
      }
    }

    /// <summary>Verifies that a bad X coordinate in query rectangle is detected</summary>
    [Test]
    public void TestBadQueryRectX() {
      Assert.Throws<ArgumentException>(
        delegate() { foreach(RectangleF r in tree.Find(0, 0, -1, 1)) { } }
      );
    }

    /// <summary>Verifies that a bad Y coordinate in query rectangle is detected</summary>
    [Test]
    public void TestBadQueryRectY() {
      Assert.Throws<ArgumentException>(
        delegate() { foreach(RectangleF r in tree.Find(0, 0, 1, -1)) { } }
      );
    }

    /// <summary>
    ///   Verifies that an exception is thrown if the tree is loaded multiple times
    /// </summary>
    [Test]
    public void TestMultiLoad() {
      RectangleF rx = new RectangleF(0, 0, 1, 1);
      tree.Load(new RectangleF[] { rx });
      Assert.Throws<InvalidOperationException>(
        delegate() { tree.Load(new RectangleF[] { rx }); }
      );
    }

    /// <summary>Tests whether the tree's height is correctly adjusted</summary>
    [Test]
    public void TestHeight() {
      const int numRects = 11;  // root and below it we have two leaf nodes 
      List<RectangleF> rects = new List<RectangleF>(numRects);
      for(int i = 0; i < numRects; i++) {
        rects.Add(new RectangleF(i, i, 10, 10));
      }
      tree.Load(rects);

      Assert.AreEqual(2, tree.Height, "height of tree");
    }

    /// <summary>Tests the PR-Tree with alare number of rectangles</summary>
    [Test]
    public void TestMany() {
      const int numRects = 1000000 / 2;
      IMBR queryInside = new SimpleMBR(495, 495, 504.9, 504.9);
      IMBR queryOutside = new SimpleMBR(1495, 495, 1504.9, 504.9);
      int shouldFindInside = 0;
      int shouldFindOutside = 0;
      List<RectangleF> rects = new List<RectangleF>(numRects * 2);
      // build an "X"
      for(int i = 0; i < numRects; i++) {
        RectangleF r1 = new RectangleF(i, i, 10, 10);
        RectangleF r2 = new RectangleF(i, numRects - i, 10, 10);

        if(queryInside.Intersects(r1, converter))
          shouldFindInside++;
        if(queryOutside.Intersects(r1, converter))
          shouldFindOutside++;
        if(queryInside.Intersects(r2, converter))
          shouldFindInside++;
        if(queryOutside.Intersects(r2, converter))
          shouldFindOutside++;

        rects.Add(r1);
        rects.Add(r2);
      }

      // shuffle, but make sure the shuffle is the same every time
      Random random = new Random(4711);
      rects.Sort(new ShuffleSortComparer(random));
      //Collections.shuffle (rects, random);
      tree.Load(rects);

      int count = 0;
      // dx = 10, each rect is 10 so 20 in total
      foreach(RectangleF r in tree.Find(queryInside))
        count++;

      Assert.AreEqual(shouldFindInside, count, "should find some rectangles");

      count = 0;
      foreach(RectangleF r in tree.Find(queryOutside))
        count++;

      Assert.AreEqual(shouldFindOutside, count, "should not find rectangles");
    }

    /// <summary>Runs a small benchmark on the PR-Tree</summary>
    [Test]
    public void TestFindSpeed() {
      int numRects = 100000;
      List<RectangleF> rects = new List<RectangleF>(numRects);
      for(int i = 0; i < numRects; i++) {
        rects.Add(new RectangleF(i, i, 10, 10));
      }

      System.Console.WriteLine("running speed test");
      tree.Load(rects);

      testFindSpeedIterator();
      testFindSpeedArray();
    }

    private void testFindSpeedIterator() {
      int count = 0;
      const int numRounds = 100000;

      Stopwatch stopwatch = Stopwatch.StartNew();

      for(int i = 0; i < numRounds; i++) {
        foreach(RectangleF r in tree.Find(295, 295, 1504.9, 5504.9)) {
          count++;
        }
      }

      stopwatch.Stop();

      System.Console.WriteLine(
        "finding " + count + " took: " + stopwatch.ElapsedMilliseconds + " millis, " +
        "average: " + (stopwatch.ElapsedTicks / numRounds / 100) + " nanos"
      );
    }

    private void testFindSpeedArray() {
      int count = 0;
      const int numRounds = 100000;

      Stopwatch stopwatch = Stopwatch.StartNew();

      for(int i = 0; i < numRounds; i++) {
        List<RectangleF> result = new List<RectangleF>(150);
        tree.Find(295, 295, 1504.9, 5504.9, result);
        foreach(RectangleF r in result) {
          count++;
        }
      }

      stopwatch.Stop();

      System.Console.WriteLine(
        "finding " + count + " took: " + stopwatch.ElapsedMilliseconds + " millis, " +
        "average: " + (stopwatch.ElapsedTicks / numRounds / 100) + " nanos"
      );
    }

    private RectangleFConverter converter = new RectangleFConverter();
    private PRTree<RectangleF> tree;

  }

} // namespace org.khelekore.prtree.nunit